package com.aiinterview.interview_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InterviewApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
